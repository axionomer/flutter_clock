# Sky Globe Clock

Digital (and analog) clock that displays weather conditions similar to a snow globe and  includes bird-oid (boid) flocking.
Gradients on hour and minutes are angled to reflect current position on an analog clock.

light - sunny
<img src='light-sun.gif' width='350'>

dark - sunny
<img src='dark-sun.gif' width='350'>

snow
<img src='dark-snow.gif' width='350'>

rain
<img src='light-rain.gif' width='350'>

wind
<img src='dark-wind.gif' width='350'>

cloudy
<img src='light-cloud.gif' width='350'>

storm
<img src='dark-storm.gif' width='350'>

foggy
<img src='light-fog.gif' width='350'>